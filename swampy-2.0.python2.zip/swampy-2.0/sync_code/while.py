# test code for while loop
counter = 0

## Thread code

while counter == 1:
    pass

while counter < 1:
    counter += 1
pass
