## Thread
# line 1
# line 2
balk()
# line 3

## Thread
# line 1
# line 2
# line 3
