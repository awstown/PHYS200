# test code for multi-line conditional statements
counter = 0

## Thread code

if counter == 0:
    print True

if counter == 1:
    print False
pass

if counter == counter+1:
    pass
    pass
else:
    print False


if True:
    print True
else:
    print False

pass




